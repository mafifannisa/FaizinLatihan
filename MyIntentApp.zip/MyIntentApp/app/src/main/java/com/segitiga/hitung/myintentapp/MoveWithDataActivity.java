package com.segitiga.hitung.myintentapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MoveWithDataActivity extends AppCompatActivity {
    public static String EXTRA_AGE = "extra_age";
    public static String EXTRA_NAME = "extra_name";
    public static String EXTRA_Alamat = "extra_alamat";
    public static String EXTRA_Email = "extra_email";
    public static String EXTRA_Nomer = "extra_Nomer";
    private TextView tvDataReceived;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_move_with_data);
        tvDataReceived = (TextView)findViewById(R.id.tv_data_received);
        String name = getIntent().getStringExtra(EXTRA_NAME);
        String Nomer = getIntent().getStringExtra(EXTRA_Nomer);
        String alamat = getIntent().getStringExtra(EXTRA_Alamat);
        String email = getIntent().getStringExtra(EXTRA_Email);
        int age = getIntent().getIntExtra(EXTRA_AGE, 0);
        String text = "Name : "+name+"\nYour Age : "+age+"\nalamat : "+alamat+"\nNomer :"+Nomer+"\nEmail : "+email;
        tvDataReceived.setText(text);
    }
}
